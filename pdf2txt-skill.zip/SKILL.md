---
name: pdf2txt
description: This skill should be used when users need to extract text content from PDF files. It provides robust text extraction from PDF documents using multiple extraction methods (pdfplumber, pypdf, pdfminer.six), with automatic method selection, support for Chinese PDFs, detailed logging, and error handling. Use this skill for tasks like "extract text from PDF", "convert PDF to text", "get PDF content", or any PDF text extraction requirements.
---

# PDF 文本提取工具

## Overview

This skill provides robust PDF text extraction capabilities using multiple extraction methods with automatic fallback. It supports Chinese PDFs, detailed processing logs, page-by-page extraction with markers, comprehensive error handling, and automatic PDF file validation. The tool includes both command-line interface and Python API usage patterns.

## Quick Start

To extract text from a PDF file, use the `scripts/pdf_extractor.py` script with the following basic command:

```bash
python scripts/pdf_extractor.py <pdf_file_path>
```

By default, the script will:
- Auto-select the best extraction method (tries pdfplumber → pypdf → pdfminer)
- Save extracted text to `<pdf_name>_extracted.txt`
- Display processing progress
- Generate detailed log file `pdf_extraction.log`

## Usage Methods

### Basic Command Line Usage

Extract text with default settings:
```bash
python scripts/pdf_extractor.py document.pdf
```

Specify output file:
```bash
python scripts/pdf_extractor.py document.pdf -o output.txt
```

Use specific extraction method:
```bash
python scripts/pdf_extractor.py document.pdf -m pdfplumber
python scripts/pdf_extractor.py document.pdf -m pypdf
python scripts/pdf_extractor.py document.pdf -m pdfminer
python scripts/pdf_extractor.py document.pdf -m auto  # default
```

Enable verbose logging:
```bash
python scripts/pdf_extractor.py document.pdf --verbose
```

### Extraction Methods

The tool supports three extraction methods with different strengths:

1. **pdfplumber** (Recommended)
   - Best for: General PDFs, Chinese content, complex layouts
   - Provides accurate page-by-page extraction with layout analysis
   - Progress tracking during extraction
   - First method tried in auto mode

2. **pypdf**
   - Best for: Lightweight extraction, basic PDFs
   - Pure Python implementation
   - Fast and memory efficient
   - Second fallback method

3. **pdfminer.six**
   - Best for: Complex layouts, precise text positioning
   - Advanced layout analysis
   - Last fallback method

In auto mode, the tool tries each method sequentially until successful extraction with sufficient content (>5 non-empty lines).

### Python API Usage

Import the main function for programmatic use:

```python
from scripts.pdf_extractor import extract_pdf_text, save_text_to_file

# Extract text
text = extract_pdf_text("document.pdf", method="auto")

if text:
    # Save to file
    save_text_to_file(text, "output.txt")
    print(f"Extracted {len(text)} characters")
else:
    print("Extraction failed")
```

## Output Format

Extracted text includes page markers for clarity:

```
=== Page 1 ===
Content of page 1...

=== Page 2 ===
Content of page 2...
```

This makes it easy to identify which page content came from.

## Error Handling

The tool handles various error conditions:

- **File not found**: Clear error message
- **Invalid PDF**: Checks PDF signature (`%PDF`)
- **Encrypted PDF**: Reports extraction failure with suggestions
- **Scanned PDFs**: Detects when all methods fail and suggests OCR solutions
- **Missing dependencies**: Provides installation commands
- **Permission errors**: Checks file read/write access

## Troubleshooting

### Extraction Returns No Text

Possible causes and solutions:

1. **PDF is a scanned document (image-based)**
   - Solution: Use OCR tools like Tesseract with pdf2image
   - Try online OCR services

2. **PDF is encrypted/password-protected**
   - Solution: Decrypt PDF first using appropriate tools

3. **File is corrupted**
   - Solution: Try recovering PDF with repair tools

4. **Missing dependencies**
   - Solution: Install dependencies:
     ```bash
     pip install -r requirements.txt
     ```

5. **Extraction method not suitable**
   - Solution: Try different methods with `-m` flag
   - Example: `python scripts/pdf_extractor.py file.pdf -m pypdf`

### Performance Considerations

- Large PDFs (>100MB) may take several minutes
- Processing speed depends on:
  - PDF size and page count
  - Extraction method used
  - System resources
- Progress updates every 10 pages

## Dependencies

Required Python packages (listed in `requirements.txt`):

```
pdfplumber>=0.10.0    # Recommended, supports Chinese and layout analysis
pypdf>=3.0.0          # Lightweight, pure Python
pdfminer.six>=20221105 # Precise layout analysis
```

Install all dependencies:
```bash
pip install -r requirements.txt
```

Or install individually:
```bash
pip install pdfplumber pypdf pdfminer.six
```

## Workflow Decision Tree

1. **User requests PDF text extraction**
   → Proceed to Step 2

2. **Determine extraction needs**
   - Command-line usage? → Use `python scripts/pdf_extractor.py`
   - Programmatic usage? → Import `extract_pdf_text` function
   - Proceed to Step 3

3. **Choose extraction method**
   - Let tool decide? → Use default `auto` mode
   - Specific method preference? → Use `-m` flag with method name
   - Proceed to Step 4

4. **Execute extraction**
   - Run extraction with chosen parameters
   - Monitor progress through console output
   - Check log file for detailed information
   - Proceed to Step 5

5. **Handle results**
   - Success: Text saved to output file
   - Failure: Check error message and troubleshooting guide
   - Try alternative extraction method if needed

## Resources

### scripts/
Contains executable code for PDF text extraction:

- **pdf_extractor.py**: Main extraction script with multiple methods, auto-selection, and comprehensive error handling

This script can be executed directly from command line or imported as a Python module for programmatic use.
